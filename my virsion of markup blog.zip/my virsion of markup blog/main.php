<!DOCTYPE html>
<html>
<head>


    <link rel="stylesheet" href="blog1.css">
</head>
<body>

<header class="site-header" >

  <div class="wrapper"><a class="site-title" rel="author" href="https://n-a-r-d.tk/Desktop/data/User/kooljool/home/sandbox/markdown/my%20virsion%20of%20markup%20blog">The Nardcart blogs </a><nav class="site-nav">


        <div class=""><a class="wgbtn" href="/about/">About</a><a class="wgbtn" href="/tut">Tutorial</a></div>
      </nav></div>
</header>
<br>
<br>


</body>
</html>