<?php
	$site_title = "nardcart";
	$img_root = "/";
?>
