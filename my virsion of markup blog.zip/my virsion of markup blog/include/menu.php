	<center><aside>

    	<div class="blog" ><h1 class="p" ><a href="post.php?id=<?= $id ?>"><?= $title ?></a></h1>
    			<small class="small">Updated <?= $date ?></small>	
		<small class="small">Author <?= $author ?></small>
    	</div>	
		
	</aside>

</center>